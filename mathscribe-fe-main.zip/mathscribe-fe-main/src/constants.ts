// src/constants.ts
const SWATCHES = [
    "#000000",  // Black
    "#ffffff",  // White
    "#ee3333",  // Red
    "#e64980",  // Pink
    "#be4bdb",  // Purple
    "#893200",  // Brown
    "#228be6",  // Blue
    "#3333ee",  // Dark Blue
    "#40c057",  // Green
    "#00aa00",  // Dark Green
    "#fab005",  // Yellow
    "#fd7e14",  // Orange
  ];
  
  export { SWATCHES };